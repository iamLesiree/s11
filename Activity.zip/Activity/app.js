const express = require('express');
const app = express();

app.get('/hello', (request, response) => {
    const message = "Hi, I am Thonie, BSCS student. I'm glad to meet you";
    response.send(message);
});

app.listen(8000, () => {
    console.log('Server is running on port 8000');
});
