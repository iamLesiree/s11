const express = require('express');
const app = express();

// Example user object with admin status
const loggedInUser = {
    username: 'admin',
    isAdmin: true
};

// Array to store items
const items = [];

// Middleware to check if the user is an admin
const checkAdmin = (req, res, next) => {
    if (loggedInUser.isAdmin) {
        next(); // Proceed to the next middleware or route handler
    } else {
        res.status(403).send('Unauthorized: Action Forbidden');
    }
};

// Route to add items
app.post('/items', checkAdmin, (req, res) => {
    // Assuming the request body contains the item data
    const newItem = req.body;
    items.push(newItem);
    console.log(items);
    res.send('You have added a new item.');
});

// Route to get all items
app.get('/items', checkAdmin, (req, res) => {
    res.send(items);
});

app.listen(8000, () => {
    console.log('Server is running on port 8000');
});
